function generatePDF() {
    var nama = document.getElementById('nama').value;
    var email = document.getElementById('email').value;
    var kategori = document.getElementById('pilih').value;
    var jumlahTiket = parseInt(document.getElementById('jumlah-tiket').value);
    
    var harga;
    switch(kategori) {
        case 'Agak Laen':
            harga = 50000;
            break;
        case "Mothers' Instinct":
            harga = 45000;
            break;
        case 'Exhuma':
            harga = 40000;
            break;
        case 'Kung Fu Panda 4':
            harga = 35000;
            break;
        case 'Madame Web':
            harga = 30000;
            break;
    }
    
    if(isNaN(jumlahTiket) || jumlahTiket <= 0) {
        alert("Jumlah tiket tidak valid");
        return;
    }
    
    var totalHarga = jumlahTiket * harga;
    
    var pdfURL = 'generate_pdf nama=' + encodeURIComponent(nama) + '&email=' + encodeURIComponent(email) + '&kategori=' + kategori + '&jumlahTiket=' + jumlahTiket + '&totalHarga=' + totalHarga;
    
    window.location = pdfURL;
}
